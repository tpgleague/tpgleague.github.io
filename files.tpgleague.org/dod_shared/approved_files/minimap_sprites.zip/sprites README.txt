These files are to be placed into:
C:\Program Files\Steam\SteamApps\email@email.com\day of defeat\dod\Sprites

Made by: Cypher

CAL-DoD|Riopelle
02-28-06