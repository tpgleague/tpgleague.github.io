//Dod_Thunder2_b2


//1. Place the ace.wad in "...Steam\steamapps\common\Half-Life\dod" 
	//this is the texture file used when creating the map
//2. Place the .bsp and assocaited .txt file found within the "maps" folder in your "...Steam\steamapps\common\Half-Life\dod_downloads\maps" 
	//this is the actual map and storyline text
//3. Place the .bmp and associated .txt file found within the "overviews" folder in your "...Steam\steamapps\common\Half-Life\dod_downloads\overviews" 
	//this is your minimap

//4. For server owners running 6v6 competition, save the "tpg_thunder2.cfg" within your root dod folder on the server. This assumes tpgbasic.cfg is already on your server.

//www.nineteeneleven.org
//Day of Defeat 1.3 server on Discord